import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface Task {
  id: string;
  assignee: string;
  task: string;
  deadline: string;
  status: "pending" | "completed";
}

export interface MeetingData {
  id: string;
  title: string;
  date: string;
  transcript: string;
  speakers: { name: string; segments: string[] }[];
  summary: string[];
  tasks: Task[];
  language: string;
}

interface MeetingStore {
  currentMeeting: MeetingData | null;
  meetings: MeetingData[];
  setCurrentMeeting: (meeting: MeetingData) => void;
  updateCurrentMeeting: (updates: Partial<MeetingData>) => void;
  updateTask: (taskId: string, updates: Partial<Task>) => void;
  addMeeting: (meeting: MeetingData) => void;
  clearCurrentMeeting: () => void;
}

export const useMeetingStore = create<MeetingStore>()(
  persist(
    (set, get) => ({
      currentMeeting: null,
      meetings: [],
      setCurrentMeeting: (meeting) => set({ currentMeeting: meeting }),
      updateCurrentMeeting: (updates) =>
        set((state) => ({
          currentMeeting: state.currentMeeting
            ? { ...state.currentMeeting, ...updates }
            : null,
        })),
      updateTask: (taskId, updates) =>
        set((state) => ({
          currentMeeting: state.currentMeeting
            ? {
                ...state.currentMeeting,
                tasks: state.currentMeeting.tasks.map((task) =>
                  task.id === taskId ? { ...task, ...updates } : task
                ),
              }
            : null,
        })),
      addMeeting: (meeting) =>
        set((state) => ({ meetings: [...state.meetings, meeting] })),
      clearCurrentMeeting: () => set({ currentMeeting: null }),
    }),
    {
      name: "syncnotes-meetings",
    }
  )
);

// Demo meeting data
export const demoMeetingData: MeetingData = {
  id: "demo-meeting-1",
  title: "Q4 Product Planning Meeting",
  date: new Date().toISOString(),
  transcript: `[00:00:00] Sarah: Good morning everyone. Let's start with our Q4 product planning session.

[00:00:15] Mike: Thanks Sarah. I've prepared the roadmap overview. Our main focus should be the mobile app launch.

[00:00:45] Sarah: Agreed. What's the timeline looking like for the mobile app?

[00:01:10] Mike: We're targeting end of November for the beta release. The core features are almost ready.

[00:01:30] Lisa: I've been working on the backend API. We need to finalize the authentication flow by next week.

[00:02:00] Sarah: Lisa, can you document the API endpoints and share them with the frontend team?

[00:02:20] Lisa: Sure, I'll have that ready by Wednesday.

[00:02:45] Mike: We also need to discuss the marketing strategy. David, any updates?

[00:03:10] David: I've drafted the launch campaign. We're planning social media teasers starting October 15th.

[00:03:40] Sarah: Perfect. Let's set up a follow-up meeting next Monday to review progress. Mike, can you send out the calendar invite?

[00:04:00] Mike: Will do. I'll also update the project board with today's decisions.

[00:04:20] Sarah: Great work everyone. Let's make Q4 our best quarter yet!`,
  speakers: [
    { name: "Sarah", segments: ["Good morning everyone...", "Agreed. What's the timeline...", "Lisa, can you document...", "Perfect. Let's set up..."] },
    { name: "Mike", segments: ["Thanks Sarah. I've prepared...", "We're targeting end of November...", "We also need to discuss...", "Will do. I'll also update..."] },
    { name: "Lisa", segments: ["I've been working on the backend...", "Sure, I'll have that ready..."] },
    { name: "David", segments: ["I've drafted the launch campaign..."] },
  ],
  summary: [
    "Mobile app beta release targeted for end of November",
    "Authentication flow needs to be finalized by next week",
    "Marketing campaign with social media teasers starting October 15th",
    "Follow-up meeting scheduled for next Monday to review progress",
    "Focus on making Q4 the best quarter for the team",
  ],
  tasks: [
    {
      id: "task-1",
      assignee: "Lisa",
      task: "Document API endpoints and share with frontend team",
      deadline: "Wednesday",
      status: "pending",
    },
    {
      id: "task-2",
      assignee: "Mike",
      task: "Send calendar invite for Monday follow-up meeting",
      deadline: "Today",
      status: "pending",
    },
    {
      id: "task-3",
      assignee: "Mike",
      task: "Update project board with today's decisions",
      deadline: "Today",
      status: "pending",
    },
    {
      id: "task-4",
      assignee: "David",
      task: "Finalize marketing campaign materials",
      deadline: "October 15th",
      status: "pending",
    },
    {
      id: "task-5",
      assignee: "Lisa",
      task: "Complete authentication flow implementation",
      deadline: "Next week",
      status: "pending",
    },
  ],
  language: "en",
};
