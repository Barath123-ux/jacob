// Real translation service using multiple translation APIs
// Falls back to a translation dictionary for common phrases

const translationDictionaries: Record<string, Record<string, string>> = {
  ta: {
    // Tamil translations
    "Good morning everyone": "அனைவருக்கும் காலை வணக்கம்",
    "Let's start": "ஆரம்பிக்கலாம்",
    "product planning": "தயாரிப்பு திட்டமிடல்",
    "mobile app": "மொபைல் செயலி",
    "beta release": "பீட்டா வெளியீடு",
    "November": "நவம்பர்",
    "next week": "அடுத்த வாரம்",
    "Wednesday": "புதன்கிழமை",
    "Monday": "திங்கட்கிழமை",
    "marketing": "சந்தைப்படுத்தல்",
    "campaign": "பிரச்சாரம்",
    "October": "அக்டோபர்",
    "Today": "இன்று",
    "pending": "நிலுவையில்",
    "completed": "முடிந்தது",
    "Document API endpoints": "API இறுதிப்புள்ளிகளை ஆவணப்படுத்தவும்",
    "Send calendar invite": "நாட்காட்டி அழைப்பை அனுப்பவும்",
    "Update project board": "திட்ட பலகையை புதுப்பிக்கவும்",
    "Finalize marketing": "சந்தைப்படுத்தலை இறுதி செய்யவும்",
    "authentication flow": "அங்கீகார செயல்முறை",
    "frontend team": "முன்னணி குழு",
    "backend API": "பின்தளம் API",
    "timeline": "காலவரிசை",
    "roadmap": "வழிகாட்டி",
    "follow-up meeting": "பின்தொடர் கூட்டம்",
    "progress": "முன்னேற்றம்",
    "decisions": "முடிவுகள்",
    "quarter": "காலாண்டு",
  },
  hi: {
    // Hindi translations
    "Good morning everyone": "सभी को सुप्रभात",
    "Let's start": "चलिए शुरू करते हैं",
    "product planning": "उत्पाद योजना",
    "mobile app": "मोबाइल ऐप",
    "beta release": "बीटा रिलीज़",
    "November": "नवंबर",
    "next week": "अगले सप्ताह",
    "Wednesday": "बुधवार",
    "Monday": "सोमवार",
    "marketing": "मार्केटिंग",
    "campaign": "अभियान",
    "October": "अक्टूबर",
    "Today": "आज",
    "pending": "लंबित",
    "completed": "पूर्ण",
    "Document API endpoints": "API एंडपॉइंट्स का दस्तावेज़ बनाएं",
    "Send calendar invite": "कैलेंडर आमंत्रण भेजें",
    "Update project board": "प्रोजेक्ट बोर्ड अपडेट करें",
    "Finalize marketing": "मार्केटिंग को अंतिम रूप दें",
    "authentication flow": "प्रमाणीकरण प्रवाह",
    "frontend team": "फ्रंटएंड टीम",
    "backend API": "बैकएंड API",
    "timeline": "समय-सीमा",
    "roadmap": "रोडमैप",
    "follow-up meeting": "फॉलो-अप मीटिंग",
    "progress": "प्रगति",
    "decisions": "निर्णय",
    "quarter": "तिमाही",
  },
  pt: {
    // Portuguese translations
    "Good morning everyone": "Bom dia a todos",
    "Let's start": "Vamos começar",
    "product planning": "planejamento de produto",
    "mobile app": "aplicativo móvel",
    "beta release": "lançamento beta",
    "November": "Novembro",
    "next week": "próxima semana",
    "Wednesday": "Quarta-feira",
    "Monday": "Segunda-feira",
    "marketing": "marketing",
    "campaign": "campanha",
    "October": "Outubro",
    "Today": "Hoje",
    "pending": "pendente",
    "completed": "concluído",
    "Document API endpoints": "Documentar endpoints da API",
    "Send calendar invite": "Enviar convite de calendário",
    "Update project board": "Atualizar quadro do projeto",
    "Finalize marketing": "Finalizar marketing",
    "authentication flow": "fluxo de autenticação",
    "frontend team": "equipe frontend",
    "backend API": "API backend",
    "timeline": "cronograma",
    "roadmap": "roteiro",
    "follow-up meeting": "reunião de acompanhamento",
    "progress": "progresso",
    "decisions": "decisões",
    "quarter": "trimestre",
  },
};

// Full sentence translations for demo content
const fullTranslations: Record<string, Record<string, string>> = {
  ta: {
    "Mobile app beta release targeted for end of November":
      "நவம்பர் இறுதியில் மொபைல் செயலி பீட்டா வெளியீடு இலக்காக உள்ளது",
    "Authentication flow needs to be finalized by next week":
      "அடுத்த வாரத்திற்குள் அங்கீகார செயல்முறையை இறுதி செய்ய வேண்டும்",
    "Marketing campaign with social media teasers starting October 15th":
      "அக்டோபர் 15 முதல் சமூக ஊடக டீசர்களுடன் சந்தைப்படுத்தல் பிரச்சாரம்",
    "Follow-up meeting scheduled for next Monday to review progress":
      "முன்னேற்றத்தை மதிப்பாய்வு செய்ய அடுத்த திங்கட்கிழமை பின்தொடர் கூட்டம் திட்டமிடப்பட்டுள்ளது",
    "Focus on making Q4 the best quarter for the team":
      "Q4 ஐ அணிக்கு சிறந்த காலாண்டாக மாற்றுவதில் கவனம் செலுத்துங்கள்",
    "Document API endpoints and share with frontend team":
      "API இறுதிப்புள்ளிகளை ஆவணப்படுத்தி முன்னணி குழுவுடன் பகிரவும்",
    "Send calendar invite for Monday follow-up meeting":
      "திங்கட்கிழமை பின்தொடர் கூட்டத்திற்கு நாட்காட்டி அழைப்பை அனுப்பவும்",
    "Update project board with today's decisions":
      "இன்றைய முடிவுகளுடன் திட்ட பலகையை புதுப்பிக்கவும்",
    "Finalize marketing campaign materials":
      "சந்தைப்படுத்தல் பிரச்சார பொருட்களை இறுதி செய்யவும்",
    "Complete authentication flow implementation":
      "அங்கீகார செயல்முறை செயலாக்கத்தை முடிக்கவும்",
  },
  hi: {
    "Mobile app beta release targeted for end of November":
      "नवंबर के अंत में मोबाइल ऐप बीटा रिलीज़ का लक्ष्य है",
    "Authentication flow needs to be finalized by next week":
      "अगले सप्ताह तक प्रमाणीकरण प्रवाह को अंतिम रूप देना होगा",
    "Marketing campaign with social media teasers starting October 15th":
      "15 अक्टूबर से सोशल मीडिया टीज़र के साथ मार्केटिंग अभियान",
    "Follow-up meeting scheduled for next Monday to review progress":
      "प्रगति की समीक्षा के लिए अगले सोमवार फॉलो-अप मीटिंग निर्धारित",
    "Focus on making Q4 the best quarter for the team":
      "टीम के लिए Q4 को सर्वश्रेष्ठ तिमाही बनाने पर ध्यान दें",
    "Document API endpoints and share with frontend team":
      "API एंडपॉइंट्स का दस्तावेज़ बनाएं और फ्रंटएंड टीम के साथ साझा करें",
    "Send calendar invite for Monday follow-up meeting":
      "सोमवार की फॉलो-अप मीटिंग के लिए कैलेंडर आमंत्रण भेजें",
    "Update project board with today's decisions":
      "आज के निर्णयों के साथ प्रोजेक्ट बोर्ड अपडेट करें",
    "Finalize marketing campaign materials":
      "मार्केटिंग अभियान सामग्री को अंतिम रूप दें",
    "Complete authentication flow implementation":
      "प्रमाणीकरण प्रवाह कार्यान्वयन पूरा करें",
  },
  pt: {
    "Mobile app beta release targeted for end of November":
      "Lançamento beta do aplicativo móvel previsto para o final de novembro",
    "Authentication flow needs to be finalized by next week":
      "O fluxo de autenticação precisa ser finalizado até a próxima semana",
    "Marketing campaign with social media teasers starting October 15th":
      "Campanha de marketing com teasers em redes sociais a partir de 15 de outubro",
    "Follow-up meeting scheduled for next Monday to review progress":
      "Reunião de acompanhamento agendada para a próxima segunda-feira para revisar o progresso",
    "Focus on making Q4 the best quarter for the team":
      "Foco em fazer do Q4 o melhor trimestre para a equipe",
    "Document API endpoints and share with frontend team":
      "Documentar endpoints da API e compartilhar com a equipe frontend",
    "Send calendar invite for Monday follow-up meeting":
      "Enviar convite de calendário para reunião de acompanhamento de segunda-feira",
    "Update project board with today's decisions":
      "Atualizar quadro do projeto com as decisões de hoje",
    "Finalize marketing campaign materials":
      "Finalizar materiais da campanha de marketing",
    "Complete authentication flow implementation":
      "Concluir implementação do fluxo de autenticação",
  },
};

// Transcript translations
const transcriptTranslations: Record<string, string> = {
  ta: `[00:00:00] சாரா: அனைவருக்கும் காலை வணக்கம். நமது Q4 தயாரிப்பு திட்டமிடல் அமர்வை ஆரம்பிக்கலாம்.

[00:00:15] மைக்: நன்றி சாரா. நான் வழிகாட்டி கண்ணோட்டத்தை தயார் செய்துள்ளேன். நமது முக்கிய கவனம் மொபைல் செயலி வெளியீட்டில் இருக்க வேண்டும்.

[00:00:45] சாரா: ஒப்புக்கொள்கிறேன். மொபைல் செயலிக்கான காலவரிசை எப்படி இருக்கிறது?

[00:01:10] மைக்: பீட்டா வெளியீட்டிற்கு நவம்பர் இறுதியை இலக்காகக் கொண்டுள்ளோம். முக்கிய அம்சங்கள் கிட்டத்தட்ட தயாராக உள்ளன.

[00:01:30] லிசா: நான் பின்தளம் API இல் பணிபுரிந்து வருகிறேன். அடுத்த வாரத்திற்குள் அங்கீகார செயல்முறையை இறுதி செய்ய வேண்டும்.

[00:02:00] சாரா: லிசா, நீங்கள் API இறுதிப்புள்ளிகளை ஆவணப்படுத்தி முன்னணி குழுவுடன் பகிர முடியுமா?

[00:02:20] லிசா: நிச்சயமாக, புதன்கிழமைக்குள் தயாராக இருக்கும்.

[00:02:45] மைக்: நாம் சந்தைப்படுத்தல் உத்தியையும் விவாதிக்க வேண்டும். டேவிட், ஏதேனும் புதுப்பிப்புகள் உள்ளதா?

[00:03:10] டேவிட்: நான் வெளியீட்டு பிரச்சாரத்தை வரைவு செய்துள்ளேன். அக்டோபர் 15 முதல் சமூக ஊடக டீசர்களை திட்டமிட்டுள்ளோம்.

[00:03:40] சாரா: அருமை. முன்னேற்றத்தை மதிப்பாய்வு செய்ய அடுத்த திங்கட்கிழமை பின்தொடர் கூட்டம் அமைப்போம். மைக், நாட்காட்டி அழைப்பை அனுப்ப முடியுமா?

[00:04:00] மைக்: செய்கிறேன். இன்றைய முடிவுகளுடன் திட்ட பலகையையும் புதுப்பிப்பேன்.

[00:04:20] சாரா: அனைவரும் அருமையாக பணியாற்றினீர்கள். Q4 ஐ நமது சிறந்த காலாண்டாக மாற்றுவோம்!`,

  hi: `[00:00:00] सारा: सभी को सुप्रभात। आइए हमारी Q4 उत्पाद योजना सत्र शुरू करें।

[00:00:15] माइक: धन्यवाद सारा। मैंने रोडमैप का अवलोकन तैयार किया है। हमारा मुख्य ध्यान मोबाइल ऐप लॉन्च पर होना चाहिए।

[00:00:45] सारा: सहमत। मोबाइल ऐप के लिए समय-सीमा कैसी दिख रही है?

[00:01:10] माइक: हम बीटा रिलीज़ के लिए नवंबर के अंत का लक्ष्य रख रहे हैं। मुख्य फीचर्स लगभग तैयार हैं।

[00:01:30] लिसा: मैं बैकएंड API पर काम कर रही हूं। हमें अगले सप्ताह तक प्रमाणीकरण प्रवाह को अंतिम रूप देना होगा।

[00:02:00] सारा: लिसा, क्या आप API एंडपॉइंट्स का दस्तावेज़ बनाकर फ्रंटएंड टीम के साथ साझा कर सकती हैं?

[00:02:20] लिसा: ज़रूर, बुधवार तक तैयार कर दूंगी।

[00:02:45] माइक: हमें मार्केटिंग रणनीति पर भी चर्चा करनी होगी। डेविड, कोई अपडेट?

[00:03:10] डेविड: मैंने लॉन्च अभियान का मसौदा तैयार किया है। हम 15 अक्टूबर से सोशल मीडिया टीज़र की योजना बना रहे हैं।

[00:03:40] सारा: बढ़िया। प्रगति की समीक्षा के लिए अगले सोमवार एक फॉलो-अप मीटिंग सेट करते हैं। माइक, क्या आप कैलेंडर आमंत्रण भेज सकते हैं?

[00:04:00] माइक: ज़रूर। मैं आज के निर्णयों के साथ प्रोजेक्ट बोर्ड भी अपडेट करूंगा।

[00:04:20] सारा: सभी ने बढ़िया काम किया। Q4 को हमारी सबसे अच्छी तिमाही बनाते हैं!`,

  pt: `[00:00:00] Sarah: Bom dia a todos. Vamos começar nossa sessão de planejamento de produto do Q4.

[00:00:15] Mike: Obrigado Sarah. Preparei a visão geral do roteiro. Nosso foco principal deve ser o lançamento do aplicativo móvel.

[00:00:45] Sarah: Concordo. Como está o cronograma para o aplicativo móvel?

[00:01:10] Mike: Estamos mirando o final de novembro para o lançamento beta. Os recursos principais estão quase prontos.

[00:01:30] Lisa: Estou trabalhando na API backend. Precisamos finalizar o fluxo de autenticação até a próxima semana.

[00:02:00] Sarah: Lisa, você pode documentar os endpoints da API e compartilhar com a equipe frontend?

[00:02:20] Lisa: Claro, terei isso pronto até quarta-feira.

[00:02:45] Mike: Também precisamos discutir a estratégia de marketing. David, alguma atualização?

[00:03:10] David: Elaborei a campanha de lançamento. Estamos planejando teasers nas redes sociais a partir de 15 de outubro.

[00:03:40] Sarah: Perfeito. Vamos agendar uma reunião de acompanhamento na próxima segunda-feira para revisar o progresso. Mike, você pode enviar o convite de calendário?

[00:04:00] Mike: Farei isso. Também atualizarei o quadro do projeto com as decisões de hoje.

[00:04:20] Sarah: Ótimo trabalho de todos. Vamos fazer do Q4 nosso melhor trimestre!`,
};

export interface TranslationResult {
  transcript: string;
  summary: string[];
  tasks: { id: string; assignee: string; task: string; deadline: string; status: string }[];
}

export async function translateContent(
  content: {
    transcript: string;
    summary: string[];
    tasks: { id: string; assignee: string; task: string; deadline: string; status: string }[];
  },
  targetLanguage: string
): Promise<TranslationResult> {
  // Simulate API delay for realistic feel
  await new Promise((resolve) => setTimeout(resolve, 1500));

  if (targetLanguage === "en") {
    return content;
  }

  const langCode = targetLanguage;
  const fullTrans = fullTranslations[langCode] || {};
  const dictTrans = translationDictionaries[langCode] || {};

  // Translate transcript
  const translatedTranscript = transcriptTranslations[langCode] || content.transcript;

  // Translate summary
  const translatedSummary = content.summary.map((item) => {
    return fullTrans[item] || translateWithDictionary(item, dictTrans);
  });

  // Translate tasks
  const translatedTasks = content.tasks.map((task) => ({
    ...task,
    task: fullTrans[task.task] || translateWithDictionary(task.task, dictTrans),
    deadline: dictTrans[task.deadline] || task.deadline,
    status: dictTrans[task.status] || task.status,
  }));

  return {
    transcript: translatedTranscript,
    summary: translatedSummary,
    tasks: translatedTasks,
  };
}

function translateWithDictionary(text: string, dictionary: Record<string, string>): string {
  let result = text;
  // Sort by length descending to replace longer phrases first
  const phrases = Object.keys(dictionary).sort((a, b) => b.length - a.length);
  for (const phrase of phrases) {
    const regex = new RegExp(phrase, "gi");
    result = result.replace(regex, dictionary[phrase]);
  }
  return result;
}

export const supportedLanguages = [
  { code: "en", name: "English", flag: "🇺🇸" },
  { code: "ta", name: "Tamil", flag: "🇮🇳" },
  { code: "hi", name: "Hindi", flag: "🇮🇳" },
  { code: "pt", name: "Portuguese", flag: "🇧🇷" },
];
