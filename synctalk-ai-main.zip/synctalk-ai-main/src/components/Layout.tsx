import { ReactNode } from "react";
import { Navbar } from "./Navbar";

interface LayoutProps {
  children: ReactNode;
  title?: string;
  showTitle?: boolean;
}

export function Layout({ children, title, showTitle = true }: LayoutProps) {
  return (
    <div className="min-h-screen bg-background relative glow-overlay">
      <Navbar />
      <main className="pt-16">
        {showTitle && title && (
          <div className="container mx-auto px-4 py-8">
            <h1 className="text-3xl font-bold text-foreground">{title}</h1>
          </div>
        )}
        {children}
      </main>
    </div>
  );
}
