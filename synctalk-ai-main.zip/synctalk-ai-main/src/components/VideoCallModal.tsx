import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Mic, MicOff, Video, VideoOff, PhoneOff, Users, Sparkles } from "lucide-react";
import { useState, useEffect } from "react";

interface VideoCallModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function VideoCallModal({ open, onOpenChange }: VideoCallModalProps) {
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraOff, setIsCameraOff] = useState(false);
  const [callEnded, setCallEnded] = useState(false);
  const [transcriptLines, setTranscriptLines] = useState<string[]>([]);

  const demoTranscripts = [
    "Sarah: Let's discuss the Q4 roadmap priorities...",
    "Mike: I think we should focus on the mobile app first.",
    "Sarah: Good point. What about the API integration?",
    "Lisa: I can handle the backend work for that.",
    "Mike: Perfect. Let's set a deadline for next Friday.",
    "Sarah: Agreed. I'll create the tasks after this call.",
  ];

  useEffect(() => {
    if (open && !callEnded) {
      setTranscriptLines([]);
      let index = 0;
      const interval = setInterval(() => {
        if (index < demoTranscripts.length) {
          setTranscriptLines(prev => [...prev, demoTranscripts[index]]);
          index++;
        }
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [open, callEnded]);

  const handleEndCall = () => {
    setCallEnded(true);
    setTimeout(() => {
      onOpenChange(false);
      setCallEnded(false);
      setIsMuted(false);
      setIsCameraOff(false);
      setTranscriptLines([]);
    }, 2000);
  };

  const handleClose = () => {
    onOpenChange(false);
    setCallEnded(false);
    setIsMuted(false);
    setIsCameraOff(false);
    setTranscriptLines([]);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl glass-card border-border/50 p-0 overflow-hidden">
        <DialogHeader className="p-4 border-b border-border/50">
          <DialogTitle className="flex items-center gap-2">
            <Video className="w-5 h-5 text-primary" />
            Demo Video Call
            <span className="text-xs bg-warning/20 text-warning px-2 py-0.5 rounded-full">
              Demo Mode
            </span>
          </DialogTitle>
        </DialogHeader>

        {callEnded ? (
          <div className="h-[500px] flex items-center justify-center">
            <div className="text-center animate-scale-in">
              <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-destructive/20 flex items-center justify-center">
                <PhoneOff className="w-10 h-10 text-destructive" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-2">Meeting Ended</h3>
              <p className="text-muted-foreground">Your meeting notes are being processed...</p>
            </div>
          </div>
        ) : (
          <>
            {/* Video Grid */}
            <div className="grid grid-cols-2 gap-2 p-4 bg-background/50">
              {/* Main Video */}
              <div className="relative aspect-video rounded-xl overflow-hidden bg-secondary">
                {isCameraOff ? (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-24 h-24 rounded-full bg-muted flex items-center justify-center">
                      <span className="text-3xl font-bold text-muted-foreground">S</span>
                    </div>
                  </div>
                ) : (
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-purple-600/20 animate-pulse">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-24 h-24 rounded-full bg-primary/30 flex items-center justify-center">
                        <span className="text-3xl font-bold text-foreground">You</span>
                      </div>
                    </div>
                  </div>
                )}
                <div className="absolute bottom-3 left-3 flex items-center gap-2">
                  <span className="px-2 py-1 bg-background/80 rounded text-xs text-foreground">You</span>
                  {isMuted && <MicOff className="w-4 h-4 text-destructive" />}
                </div>
              </div>

              {/* Participant Videos */}
              {["Sarah", "Mike", "Lisa"].map((name) => (
                <div key={name} className="relative aspect-video rounded-xl overflow-hidden bg-secondary">
                  <div className="absolute inset-0 bg-gradient-to-br from-secondary to-muted">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
                        <span className="text-xl font-bold text-muted-foreground">{name[0]}</span>
                      </div>
                    </div>
                  </div>
                  <div className="absolute bottom-3 left-3">
                    <span className="px-2 py-1 bg-background/80 rounded text-xs text-foreground">{name}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Live Captions */}
            <div className="px-4 pb-2">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-4 h-4 text-primary animate-pulse" />
                <span className="text-xs text-primary font-medium">AI is listening...</span>
              </div>
              <div className="h-24 overflow-y-auto bg-secondary/50 rounded-lg p-3 space-y-1">
                {transcriptLines.length === 0 ? (
                  <p className="text-xs text-muted-foreground italic">Waiting for speech...</p>
                ) : (
                  transcriptLines.map((line, idx) => (
                    <p key={idx} className="text-xs text-foreground animate-fade-in">{line}</p>
                  ))
                )}
              </div>
            </div>

            {/* Controls */}
            <div className="p-4 border-t border-border/50 flex items-center justify-center gap-4">
              <Button
                variant={isMuted ? "destructive" : "secondary"}
                size="lg"
                className="w-14 h-14 rounded-full"
                onClick={() => setIsMuted(!isMuted)}
              >
                {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
              </Button>
              <Button
                variant={isCameraOff ? "destructive" : "secondary"}
                size="lg"
                className="w-14 h-14 rounded-full"
                onClick={() => setIsCameraOff(!isCameraOff)}
              >
                {isCameraOff ? <VideoOff className="w-6 h-6" /> : <Video className="w-6 h-6" />}
              </Button>
              <Button
                variant="destructive"
                size="lg"
                className="w-14 h-14 rounded-full"
                onClick={handleEndCall}
              >
                <PhoneOff className="w-6 h-6" />
              </Button>
              <Button
                variant="secondary"
                size="lg"
                className="w-14 h-14 rounded-full"
              >
                <Users className="w-6 h-6" />
              </Button>
            </div>

            <p className="text-center text-xs text-muted-foreground pb-4">
              Demo Video Call – No real video is captured
            </p>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
