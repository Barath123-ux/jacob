import { Link, useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Home, ArrowLeft, Menu, X } from "lucide-react";
import { useState } from "react";

export function Navbar() {
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const isHomePage = location.pathname === "/";

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-xl">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="relative w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-purple-500 flex items-center justify-center shadow-lg group-hover:shadow-primary/30 transition-shadow">
              <span className="text-xl font-bold text-primary-foreground">S</span>
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold text-foreground">SyncNotes</span>
              <span className="text-[10px] text-muted-foreground uppercase tracking-wider">by Team Jacob</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-2">
            {!isHomePage && (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => navigate(-1)}
                  className="gap-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Back
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  asChild
                  className="gap-2"
                >
                  <Link to="/">
                    <Home className="w-4 h-4" />
                    Home
                  </Link>
                </Button>
              </>
            )}
            <Button
              variant="ghost"
              size="sm"
              asChild
            >
              <Link to="/dashboard">Dashboard</Link>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              asChild
            >
              <Link to="/tasks">Tasks</Link>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              asChild
            >
              <Link to="/demo">Demo</Link>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-border/50 animate-fade-in">
            <div className="flex flex-col gap-2">
              {!isHomePage && (
                <>
                  <Button
                    variant="ghost"
                    onClick={() => {
                      navigate(-1);
                      setMobileMenuOpen(false);
                    }}
                    className="justify-start gap-2"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Back
                  </Button>
                  <Button
                    variant="ghost"
                    asChild
                    className="justify-start gap-2"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <Link to="/">
                      <Home className="w-4 h-4" />
                      Home
                    </Link>
                  </Button>
                </>
              )}
              <Button
                variant="ghost"
                asChild
                className="justify-start"
                onClick={() => setMobileMenuOpen(false)}
              >
                <Link to="/dashboard">Dashboard</Link>
              </Button>
              <Button
                variant="ghost"
                asChild
                className="justify-start"
                onClick={() => setMobileMenuOpen(false)}
              >
                <Link to="/tasks">Tasks</Link>
              </Button>
              <Button
                variant="ghost"
                asChild
                className="justify-start"
                onClick={() => setMobileMenuOpen(false)}
              >
                <Link to="/demo">Demo</Link>
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
