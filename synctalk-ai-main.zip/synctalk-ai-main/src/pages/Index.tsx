import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { FeatureCard } from "@/components/FeatureCard";
import { VideoCallModal } from "@/components/VideoCallModal";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import {
  Mic,
  Upload,
  Play,
  Video,
  FileText,
  Brain,
  ListTodo,
  Trello,
  Languages,
  Radio,
  Users,
  Slack,
  Calendar,
  Github,
} from "lucide-react";

const Index = () => {
  const navigate = useNavigate();
  const [videoCallOpen, setVideoCallOpen] = useState(false);
  const [comingSoonOpen, setComingSoonOpen] = useState(false);
  const [comingSoonFeature, setComingSoonFeature] = useState("");

  const handleComingSoon = (feature: string) => {
    setComingSoonFeature(feature);
    setComingSoonOpen(true);
  };

  const features = [
    {
      icon: FileText,
      title: "AI Transcription",
      description: "Automatic speech-to-text with speaker detection",
      onClick: () => navigate("/dashboard?mode=upload"),
    },
    {
      icon: Brain,
      title: "Smart Summarization",
      description: "Key decisions and insights extracted automatically",
      onClick: () => navigate("/demo"),
    },
    {
      icon: ListTodo,
      title: "Task Extraction",
      description: "Action items with assignees and deadlines",
      onClick: () => navigate("/tasks"),
    },
    {
      icon: Trello,
      title: "Trello Integration",
      description: "Push tasks directly to your Trello boards",
      onClick: () => navigate("/dashboard"),
    },
    {
      icon: Languages,
      title: "Multi-Language Translation",
      description: "Translate to Tamil, Hindi, Portuguese & more",
      onClick: () => navigate("/demo"),
    },
    {
      icon: Radio,
      title: "Live Transcription",
      description: "Real-time transcription during calls",
      badge: "Beta",
      onClick: () => setVideoCallOpen(true),
    },
    {
      icon: Users,
      title: "Speaker Recognition",
      description: "Identify who said what in meetings",
      badge: "Beta",
      onClick: () => navigate("/demo"),
    },
  ];

  const roadmapFeatures = [
    { icon: Video, title: "Zoom Integration", description: "Connect directly to Zoom meetings" },
    { icon: Calendar, title: "Google Meet Sync", description: "Sync with Google Calendar meetings" },
    { icon: Slack, title: "Slack Integration", description: "Send summaries to Slack channels" },
    { icon: Github, title: "Jira Sync", description: "Create Jira tickets from tasks" },
  ];

  return (
    <Layout showTitle={false}>
      {/* Hero Section */}
      <section className="hero-gradient relative overflow-hidden">
        <div className="container mx-auto px-4 py-24 md:py-32">
          <div className="max-w-4xl mx-auto text-center relative z-10">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-8 animate-fade-in">
              <span className="w-2 h-2 rounded-full bg-success animate-pulse" />
              <span className="text-sm text-primary">AI-Powered Meeting Assistant</span>
            </div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 animate-slide-up">
              Meetings End.{" "}
              <span className="gradient-text">Work Begins.</span>
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto animate-slide-up" style={{ animationDelay: "0.1s" }}>
              SyncNotes is your AI meeting secretary that transcribes, summarizes, and extracts action items automatically. Never miss a task again.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-4 animate-slide-up" style={{ animationDelay: "0.2s" }}>
              <Button
                size="lg"
                className="gap-2 bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/25 hover:shadow-primary/40 transition-all"
                onClick={() => navigate("/dashboard?mode=live")}
              >
                <Mic className="w-5 h-5" />
                Start Recording
              </Button>
              <Button
                size="lg"
                variant="secondary"
                className="gap-2"
                onClick={() => navigate("/dashboard?mode=upload")}
              >
                <Upload className="w-5 h-5" />
                Upload Meeting
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="gap-2"
                onClick={() => navigate("/demo")}
              >
                <Play className="w-5 h-5" />
                Try Demo
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="gap-2 border-primary/50 text-primary hover:bg-primary/10"
                onClick={() => setVideoCallOpen(true)}
              >
                <Video className="w-5 h-5" />
                Start Video Call
              </Button>
            </div>
          </div>

          {/* Background Decorations */}
          <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl -translate-y-1/2" />
          <div className="absolute top-1/3 right-1/4 w-64 h-64 bg-purple-500/5 rounded-full blur-3xl" />
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Powerful Features for{" "}
              <span className="gradient-text">Productive Meetings</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Everything you need to turn chaotic meetings into organized action items
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-5xl mx-auto">
            {features.map((feature) => (
              <FeatureCard
                key={feature.title}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
                badge={feature.badge}
                onClick={feature.onClick}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Roadmap Section */}
      <section className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Product Roadmap
            </h2>
            <p className="text-muted-foreground">
              Exciting integrations coming soon
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 max-w-5xl mx-auto">
            {roadmapFeatures.map((feature) => (
              <FeatureCard
                key={feature.title}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
                badge="Coming Soon"
                badgeVariant="secondary"
                comingSoon
                onClick={() => handleComingSoon(feature.title)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center glass-card p-12 rounded-2xl">
            <h2 className="text-3xl font-bold mb-4">
              Ready to Transform Your Meetings?
            </h2>
            <p className="text-muted-foreground mb-8">
              Start using SyncNotes today and never miss an action item again.
            </p>
            <Button
              size="lg"
              className="gap-2 bg-primary hover:bg-primary/90"
              onClick={() => navigate("/demo")}
            >
              <Play className="w-5 h-5" />
              Try the Demo Now
            </Button>
          </div>
        </div>
      </section>

      {/* Video Call Modal */}
      <VideoCallModal open={videoCallOpen} onOpenChange={setVideoCallOpen} />

      {/* Coming Soon Modal */}
      <Dialog open={comingSoonOpen} onOpenChange={setComingSoonOpen}>
        <DialogContent className="glass-card">
          <DialogHeader>
            <DialogTitle>{comingSoonFeature}</DialogTitle>
            <DialogDescription>
              Coming Soon – Under Active Development
            </DialogDescription>
          </DialogHeader>
          <p className="text-muted-foreground">
            We're working hard to bring you this integration. Stay tuned for updates!
          </p>
          <Button onClick={() => setComingSoonOpen(false)} className="mt-4">
            Got it
          </Button>
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default Index;
