import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useMeetingStore, Task, demoMeetingData } from "@/store/meetingStore";
import { CheckCircle2, Clock, User, Edit2, UserPlus, Trash2 } from "lucide-react";

const Tasks = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { currentMeeting, updateTask, setCurrentMeeting } = useMeetingStore();
  const [filter, setFilter] = useState<"all" | "pending" | "completed">("all");
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [reassignDialogOpen, setReassignDialogOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [newAssignee, setNewAssignee] = useState("");

  // Load demo data if no current meeting
  useEffect(() => {
    if (!currentMeeting) {
      setCurrentMeeting(demoMeetingData);
    }
  }, [currentMeeting, setCurrentMeeting]);

  const tasks = currentMeeting?.tasks || [];

  const filteredTasks = tasks.filter((task) => {
    if (filter === "all") return true;
    return task.status === filter;
  });

  const handleMarkComplete = (taskId: string) => {
    const task = tasks.find(t => t.id === taskId);
    if (task) {
      const newStatus = task.status === "completed" ? "pending" : "completed";
      updateTask(taskId, { status: newStatus });
      toast({
        title: newStatus === "completed" ? "Task completed!" : "Task marked as pending",
        description: task.task.substring(0, 50) + "...",
      });
    }
  };

  const handleEditSave = () => {
    if (editingTask) {
      updateTask(editingTask.id, {
        task: editingTask.task,
        deadline: editingTask.deadline,
      });
      setEditingTask(null);
      toast({
        title: "Task updated",
        description: "Your changes have been saved",
      });
    }
  };

  const handleReassign = () => {
    if (selectedTask && newAssignee.trim()) {
      updateTask(selectedTask.id, { assignee: newAssignee.trim() });
      setReassignDialogOpen(false);
      setSelectedTask(null);
      setNewAssignee("");
      toast({
        title: "Task reassigned",
        description: `Task assigned to ${newAssignee.trim()}`,
      });
    }
  };

  const pendingCount = tasks.filter(t => t.status === "pending").length;
  const completedCount = tasks.filter(t => t.status === "completed").length;

  return (
    <Layout title="Tasks">
      <div className="container mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8 max-w-lg">
          <Card className="glass-card p-4 text-center">
            <p className="text-3xl font-bold text-foreground">{tasks.length}</p>
            <p className="text-sm text-muted-foreground">Total</p>
          </Card>
          <Card className="glass-card p-4 text-center">
            <p className="text-3xl font-bold text-warning">{pendingCount}</p>
            <p className="text-sm text-muted-foreground">Pending</p>
          </Card>
          <Card className="glass-card p-4 text-center">
            <p className="text-3xl font-bold text-success">{completedCount}</p>
            <p className="text-sm text-muted-foreground">Completed</p>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex gap-2 mb-6">
          <Button
            variant={filter === "all" ? "default" : "secondary"}
            size="sm"
            onClick={() => setFilter("all")}
          >
            All ({tasks.length})
          </Button>
          <Button
            variant={filter === "pending" ? "default" : "secondary"}
            size="sm"
            onClick={() => setFilter("pending")}
          >
            Pending ({pendingCount})
          </Button>
          <Button
            variant={filter === "completed" ? "default" : "secondary"}
            size="sm"
            onClick={() => setFilter("completed")}
          >
            Completed ({completedCount})
          </Button>
        </div>

        {/* Task List */}
        <div className="space-y-4">
          {filteredTasks.length === 0 ? (
            <Card className="glass-card p-12 text-center">
              <p className="text-muted-foreground">No tasks found</p>
            </Card>
          ) : (
            filteredTasks.map((task) => (
              <Card
                key={task.id}
                className={`glass-card p-6 transition-all ${
                  task.status === "completed" ? "opacity-60" : ""
                }`}
              >
                <div className="flex flex-col md:flex-row md:items-center gap-4">
                  <div className="flex-1">
                    <div className="flex items-start gap-3">
                      <button
                        onClick={() => handleMarkComplete(task.id)}
                        className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 mt-0.5 transition-colors ${
                          task.status === "completed"
                            ? "bg-success border-success"
                            : "border-muted-foreground hover:border-primary"
                        }`}
                      >
                        {task.status === "completed" && (
                          <CheckCircle2 className="w-4 h-4 text-success-foreground" />
                        )}
                      </button>
                      <div className="flex-1">
                        <p
                          className={`font-medium ${
                            task.status === "completed" ? "line-through text-muted-foreground" : ""
                          }`}
                        >
                          {task.task}
                        </p>
                        <div className="flex flex-wrap items-center gap-4 mt-2 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <User className="w-4 h-4" />
                            {task.assignee}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {task.deadline}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Badge variant={task.status === "completed" ? "default" : "secondary"}>
                      {task.status}
                    </Badge>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setEditingTask({ ...task })}
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        setSelectedTask(task);
                        setReassignDialogOpen(true);
                      }}
                    >
                      <UserPlus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>

        {/* Navigation */}
        <div className="flex gap-3 mt-8">
          <Button variant="secondary" onClick={() => navigate(-1)}>
            Back
          </Button>
          <Button variant="secondary" onClick={() => navigate("/")}>
            Home
          </Button>
        </div>
      </div>

      {/* Edit Dialog */}
      <Dialog open={!!editingTask} onOpenChange={() => setEditingTask(null)}>
        <DialogContent className="glass-card">
          <DialogHeader>
            <DialogTitle>Edit Task</DialogTitle>
          </DialogHeader>
          {editingTask && (
            <div className="space-y-4">
              <div>
                <Label>Task Description</Label>
                <Input
                  value={editingTask.task}
                  onChange={(e) =>
                    setEditingTask({ ...editingTask, task: e.target.value })
                  }
                />
              </div>
              <div>
                <Label>Deadline</Label>
                <Input
                  value={editingTask.deadline}
                  onChange={(e) =>
                    setEditingTask({ ...editingTask, deadline: e.target.value })
                  }
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="secondary" onClick={() => setEditingTask(null)}>
              Cancel
            </Button>
            <Button onClick={handleEditSave}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reassign Dialog */}
      <Dialog open={reassignDialogOpen} onOpenChange={setReassignDialogOpen}>
        <DialogContent className="glass-card">
          <DialogHeader>
            <DialogTitle>Reassign Task</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Current assignee: <strong>{selectedTask?.assignee}</strong>
            </p>
            <div>
              <Label>New Assignee</Label>
              <Input
                placeholder="Enter name"
                value={newAssignee}
                onChange={(e) => setNewAssignee(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setReassignDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleReassign} disabled={!newAssignee.trim()}>
              Reassign
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default Tasks;
