import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useMeetingStore, demoMeetingData } from "@/store/meetingStore";
import { Play, Loader2, Sparkles, CheckCircle2, FileAudio } from "lucide-react";

const Demo = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { setCurrentMeeting } = useMeetingStore();
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentStage, setCurrentStage] = useState("");

  const processingStages = [
    { progress: 15, message: "Loading demo audio..." },
    { progress: 30, message: "Transcribing speech with AI..." },
    { progress: 50, message: "Identifying speakers..." },
    { progress: 70, message: "Analyzing key decisions..." },
    { progress: 85, message: "Extracting action items..." },
    { progress: 100, message: "Generating summary..." },
  ];

  const handleRunDemo = async () => {
    setIsProcessing(true);
    setProgress(0);

    for (const stage of processingStages) {
      await new Promise((resolve) => setTimeout(resolve, 700));
      setProgress(stage.progress);
      setCurrentStage(stage.message);
    }

    setCurrentMeeting(demoMeetingData);
    
    toast({
      title: "Demo complete!",
      description: "View your AI-generated meeting insights",
    });

    setIsProcessing(false);
    navigate("/results");
  };

  return (
    <Layout title="Demo Mode">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {/* Demo Badge */}
          <div className="flex justify-center mb-8">
            <Badge variant="secondary" className="px-4 py-2 text-sm">
              <Sparkles className="w-4 h-4 mr-2" />
              Demo Mode – Stable Hackathon Preview
            </Badge>
          </div>

          {/* Main Demo Card */}
          <Card className="glass-card p-8">
            <div className="text-center mb-8">
              <div className="w-24 h-24 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-primary/20 to-purple-500/20 flex items-center justify-center">
                <FileAudio className="w-12 h-12 text-primary" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Q4 Product Planning Meeting</h2>
              <p className="text-muted-foreground">
                Experience SyncNotes with a pre-loaded sample meeting
              </p>
            </div>

            {/* Demo Features */}
            <div className="grid grid-cols-2 gap-3 mb-8">
              {[
                "AI Transcription",
                "Speaker Detection",
                "Smart Summary",
                "Task Extraction",
                "Multi-Language",
                "Trello Integration",
              ].map((feature) => (
                <div
                  key={feature}
                  className="flex items-center gap-2 p-3 rounded-lg bg-secondary/50"
                >
                  <CheckCircle2 className="w-4 h-4 text-success" />
                  <span className="text-sm">{feature}</span>
                </div>
              ))}
            </div>

            {/* Processing Progress */}
            {isProcessing && (
              <div className="mb-8 p-4 bg-secondary/50 rounded-lg">
                <div className="flex items-center gap-3 mb-3">
                  <Loader2 className="w-5 h-5 animate-spin text-primary" />
                  <span className="text-sm font-medium">{currentStage}</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>
            )}

            {/* Action Button */}
            <Button
              size="lg"
              className="w-full gap-2"
              onClick={handleRunDemo}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Processing Demo...
                </>
              ) : (
                <>
                  <Play className="w-5 h-5" />
                  Run Demo
                </>
              )}
            </Button>
          </Card>

          {/* Info Card */}
          <Card className="glass-card p-6 mt-6">
            <h3 className="font-semibold mb-3">What you'll see:</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                Full transcript with speaker labels (Sarah, Mike, Lisa, David)
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                5 key summary points about Q4 planning decisions
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                5 action items with assignees and deadlines
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                Real translation to Tamil, Hindi, and Portuguese
              </li>
            </ul>
          </Card>

          {/* Navigation */}
          <div className="flex gap-3 mt-8">
            <Button variant="secondary" onClick={() => navigate("/")}>
              Back to Home
            </Button>
            <Button variant="secondary" onClick={() => navigate("/dashboard")}>
              Try Your Own Audio
            </Button>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Demo;
