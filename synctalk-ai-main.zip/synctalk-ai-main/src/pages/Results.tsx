import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useMeetingStore } from "@/store/meetingStore";
import { translateContent, supportedLanguages, TranslationResult } from "@/services/translationService";
import {
  FileText,
  Brain,
  ListTodo,
  Languages,
  Trello,
  Download,
  Loader2,
  User,
  Calendar,
  CheckCircle2,
  Clock,
} from "lucide-react";

const Results = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { currentMeeting, updateCurrentMeeting } = useMeetingStore();
  const [selectedLanguage, setSelectedLanguage] = useState("en");
  const [isTranslating, setIsTranslating] = useState(false);
  const [translatedContent, setTranslatedContent] = useState<TranslationResult | null>(null);
  const [isPushingToTrello, setIsPushingToTrello] = useState(false);

  useEffect(() => {
    if (!currentMeeting) {
      navigate("/dashboard");
    }
  }, [currentMeeting, navigate]);

  if (!currentMeeting) {
    return null;
  }

  const handleTranslate = async (languageCode: string) => {
    setSelectedLanguage(languageCode);
    
    if (languageCode === "en") {
      setTranslatedContent(null);
      return;
    }

    setIsTranslating(true);
    
    try {
      const result = await translateContent(
        {
          transcript: currentMeeting.transcript,
          summary: currentMeeting.summary,
          tasks: currentMeeting.tasks.map(t => ({ ...t, status: t.status })),
        },
        languageCode
      );
      setTranslatedContent(result);
      toast({
        title: "Translation complete",
        description: `Content translated to ${supportedLanguages.find(l => l.code === languageCode)?.name}`,
      });
    } catch (error) {
      toast({
        title: "Translation failed",
        description: "Please try again later",
        variant: "destructive",
      });
    } finally {
      setIsTranslating(false);
    }
  };

  const handlePushToTrello = async () => {
    setIsPushingToTrello(true);
    
    // Simulate Trello API call
    await new Promise((resolve) => setTimeout(resolve, 2000));
    
    toast({
      title: "Tasks pushed to Trello!",
      description: `${currentMeeting.tasks.length} tasks created in your Trello board`,
    });
    
    setIsPushingToTrello(false);
  };

  const handleDownload = (format: "pdf" | "txt") => {
    const content = `
Meeting: ${currentMeeting.title}
Date: ${new Date(currentMeeting.date).toLocaleDateString()}

=== TRANSCRIPT ===
${displayedContent.transcript}

=== SUMMARY ===
${displayedContent.summary.map((s, i) => `${i + 1}. ${s}`).join("\n")}

=== ACTION ITEMS ===
${displayedContent.tasks.map((t) => `• ${t.task} (Assigned to: ${t.assignee}, Deadline: ${t.deadline})`).join("\n")}
    `.trim();

    const blob = new Blob([content], { type: format === "pdf" ? "application/pdf" : "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `meeting-notes.${format}`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Download started",
      description: `Your meeting notes are being downloaded as ${format.toUpperCase()}`,
    });
  };

  const displayedContent = translatedContent || {
    transcript: currentMeeting.transcript,
    summary: currentMeeting.summary,
    tasks: currentMeeting.tasks,
  };

  return (
    <Layout title="Meeting Results">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div>
            <h2 className="text-2xl font-bold">{currentMeeting.title}</h2>
            <p className="text-muted-foreground flex items-center gap-2 mt-1">
              <Calendar className="w-4 h-4" />
              {new Date(currentMeeting.date).toLocaleDateString("en-US", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </p>
          </div>

          {/* Actions */}
          <div className="flex flex-wrap gap-2">
            <Select value={selectedLanguage} onValueChange={handleTranslate}>
              <SelectTrigger className="w-[180px]">
                <Languages className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Translate" />
              </SelectTrigger>
              <SelectContent>
                {supportedLanguages.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    <span className="mr-2">{lang.flag}</span>
                    {lang.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button
              variant="secondary"
              onClick={handlePushToTrello}
              disabled={isPushingToTrello}
            >
              {isPushingToTrello ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Trello className="w-4 h-4 mr-2" />
              )}
              Push to Trello
            </Button>

            <Button variant="secondary" onClick={() => handleDownload("txt")}>
              <Download className="w-4 h-4 mr-2" />
              Download
            </Button>
          </div>
        </div>

        {/* Translation Loading */}
        {isTranslating && (
          <div className="mb-6 p-4 bg-primary/10 border border-primary/20 rounded-lg flex items-center gap-3">
            <Loader2 className="w-5 h-5 animate-spin text-primary" />
            <span>Translating content to {supportedLanguages.find(l => l.code === selectedLanguage)?.name}...</span>
          </div>
        )}

        {/* Results Grid */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Transcript Card */}
          <Card className="glass-card p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <FileText className="w-5 h-5 text-primary" />
              </div>
              <h3 className="text-lg font-semibold">Transcript</h3>
            </div>
            <ScrollArea className="h-[400px] pr-4">
              <div className="space-y-3">
                {displayedContent.transcript.split("\n\n").map((paragraph, idx) => (
                  <p key={idx} className="text-sm text-foreground/90 leading-relaxed">
                    {paragraph}
                  </p>
                ))}
              </div>
            </ScrollArea>
          </Card>

          {/* Summary Card */}
          <Card className="glass-card p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Brain className="w-5 h-5 text-primary" />
              </div>
              <h3 className="text-lg font-semibold">Summary</h3>
            </div>
            <ScrollArea className="h-[400px] pr-4">
              <ul className="space-y-4">
                {displayedContent.summary.map((point, idx) => (
                  <li key={idx} className="flex gap-3">
                    <CheckCircle2 className="w-5 h-5 text-success flex-shrink-0 mt-0.5" />
                    <span className="text-sm">{point}</span>
                  </li>
                ))}
              </ul>
            </ScrollArea>
          </Card>

          {/* Action Items Card */}
          <Card className="glass-card p-6 lg:col-span-2">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <ListTodo className="w-5 h-5 text-primary" />
                </div>
                <h3 className="text-lg font-semibold">Action Items</h3>
              </div>
              <Button variant="outline" size="sm" onClick={() => navigate("/tasks")}>
                View All Tasks
              </Button>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {displayedContent.tasks.map((task) => (
                <Card key={task.id} className="p-4 bg-secondary/50 border-border/50">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm font-medium">{task.assignee}</span>
                    </div>
                    <Badge variant={task.status === "completed" ? "default" : "secondary"}>
                      {task.status}
                    </Badge>
                  </div>
                  <p className="text-sm mb-3">{task.task}</p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    {task.deadline}
                  </div>
                </Card>
              ))}
            </div>
          </Card>
        </div>

        {/* Navigation Buttons */}
        <div className="flex gap-3 mt-8">
          <Button variant="secondary" onClick={() => navigate("/dashboard")}>
            Back to Dashboard
          </Button>
          <Button variant="secondary" onClick={() => navigate("/")}>
            Home
          </Button>
        </div>
      </div>
    </Layout>
  );
};

export default Results;
