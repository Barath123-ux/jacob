import { useState, useRef, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { useMeetingStore, demoMeetingData } from "@/store/meetingStore";
import { Mic, MicOff, Upload, FileAudio, Loader2, Play, Trash2 } from "lucide-react";

const Dashboard = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const mode = searchParams.get("mode") || "upload";
  const { toast } = useToast();
  const { setCurrentMeeting } = useMeetingStore();

  const [isRecording, setIsRecording] = useState(false);
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [recordingTime, setRecordingTime] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Waveform animation bars
  const [waveformBars, setWaveformBars] = useState<number[]>(Array(20).fill(20));

  useEffect(() => {
    if (isRecording) {
      const interval = setInterval(() => {
        setWaveformBars(Array(20).fill(0).map(() => Math.random() * 60 + 20));
      }, 100);
      return () => clearInterval(interval);
    } else {
      setWaveformBars(Array(20).fill(20));
    }
  }, [isRecording]);

  useEffect(() => {
    if (isRecording) {
      timerRef.current = setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isRecording]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const validTypes = ["audio/mp3", "audio/wav", "audio/m4a", "audio/mpeg", "audio/x-m4a"];
      if (validTypes.includes(file.type) || file.name.match(/\.(mp3|wav|m4a)$/i)) {
        setAudioFile(file);
        toast({
          title: "File uploaded",
          description: `${file.name} is ready for processing`,
        });
      } else {
        toast({
          title: "Invalid file type",
          description: "Please upload an MP3, WAV, or M4A file",
          variant: "destructive",
        });
      }
    }
  };

  const toggleRecording = () => {
    if (isRecording) {
      setIsRecording(false);
      toast({
        title: "Recording stopped",
        description: `Recorded ${formatTime(recordingTime)}`,
      });
    } else {
      setIsRecording(true);
      setRecordingTime(0);
      setAudioFile(null);
      toast({
        title: "Recording started",
        description: "Speak clearly into your microphone",
      });
    }
  };

  const processMeeting = async () => {
    setIsProcessing(true);
    setProgress(0);

    // Simulate processing stages
    const stages = [
      { progress: 20, message: "Uploading audio..." },
      { progress: 40, message: "Transcribing speech..." },
      { progress: 60, message: "Analyzing content..." },
      { progress: 80, message: "Extracting tasks..." },
      { progress: 100, message: "Generating summary..." },
    ];

    for (const stage of stages) {
      await new Promise((resolve) => setTimeout(resolve, 800));
      setProgress(stage.progress);
    }

    // Use demo data for the result
    const meetingData = {
      ...demoMeetingData,
      id: `meeting-${Date.now()}`,
      title: audioFile?.name || "Live Recording",
      date: new Date().toISOString(),
    };

    setCurrentMeeting(meetingData);
    setIsProcessing(false);

    toast({
      title: "Processing complete!",
      description: "Your meeting has been analyzed",
    });

    navigate("/results");
  };

  const clearAudio = () => {
    setAudioFile(null);
    setRecordingTime(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const hasAudio = audioFile || recordingTime > 0;

  return (
    <Layout title="Dashboard">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {/* Mode Toggle */}
          <div className="flex gap-2 mb-8">
            <Button
              variant={mode === "upload" ? "default" : "secondary"}
              onClick={() => navigate("/dashboard?mode=upload")}
              className="flex-1"
            >
              <Upload className="w-4 h-4 mr-2" />
              Upload Audio
            </Button>
            <Button
              variant={mode === "live" ? "default" : "secondary"}
              onClick={() => navigate("/dashboard?mode=live")}
              className="flex-1"
            >
              <Mic className="w-4 h-4 mr-2" />
              Live Recording
            </Button>
          </div>

          {/* Main Card */}
          <Card className="glass-card p-8">
            {mode === "upload" ? (
              /* Upload Mode */
              <div className="space-y-6">
                <div
                  className="border-2 border-dashed border-border rounded-xl p-12 text-center cursor-pointer hover:border-primary/50 transition-colors"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".mp3,.wav,.m4a,audio/*"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                  <FileAudio className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-semibold mb-2">
                    {audioFile ? audioFile.name : "Drop your audio file here"}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Supports MP3, WAV, M4A formats
                  </p>
                </div>

                {audioFile && (
                  <div className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                    <div className="flex items-center gap-3">
                      <FileAudio className="w-8 h-8 text-primary" />
                      <div>
                        <p className="font-medium">{audioFile.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {(audioFile.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" onClick={clearAudio}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </div>
            ) : (
              /* Live Recording Mode */
              <div className="space-y-6">
                <div className="text-center">
                  <div
                    className={`w-32 h-32 mx-auto rounded-full flex items-center justify-center cursor-pointer transition-all ${
                      isRecording
                        ? "bg-destructive/20 animate-pulse"
                        : "bg-primary/20 hover:bg-primary/30"
                    }`}
                    onClick={toggleRecording}
                  >
                    {isRecording ? (
                      <MicOff className="w-12 h-12 text-destructive" />
                    ) : (
                      <Mic className="w-12 h-12 text-primary" />
                    )}
                  </div>
                  <p className="mt-4 text-2xl font-mono font-bold">
                    {formatTime(recordingTime)}
                  </p>
                  <p className="text-sm text-muted-foreground mt-2">
                    {isRecording ? "Recording... Click to stop" : "Click to start recording"}
                  </p>
                </div>

                {/* Waveform Visualization */}
                <div className="flex items-center justify-center gap-1 h-16">
                  {waveformBars.map((height, idx) => (
                    <div
                      key={idx}
                      className={`w-2 rounded-full transition-all duration-100 ${
                        isRecording ? "bg-primary" : "bg-muted"
                      }`}
                      style={{ height: `${height}%` }}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Processing Progress */}
            {isProcessing && (
              <div className="mt-6 space-y-3">
                <div className="flex items-center gap-3">
                  <Loader2 className="w-5 h-5 animate-spin text-primary" />
                  <span className="text-sm">Processing your meeting...</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3 mt-8">
              <Button
                variant="secondary"
                onClick={() => navigate("/")}
                className="flex-1"
              >
                Back to Home
              </Button>
              <Button
                onClick={processMeeting}
                disabled={!hasAudio || isProcessing || isRecording}
                className="flex-1 gap-2"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4" />
                    Process Meeting
                  </>
                )}
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Dashboard;
